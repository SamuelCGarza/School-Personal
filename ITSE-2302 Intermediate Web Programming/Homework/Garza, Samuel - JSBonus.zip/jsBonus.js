const vowels = ['a', 'e', 'i', 'o', 'u'];

const words = ['dog', 'cat', 'teach', 'world cup', 'down', 'all', 'up', 'over', 'extra'];


sortedList = (list) => {

    // Function to sort a list of strings in alphabetical order using the quicksort algorithm.

    // Define the base case
    if (list.length <= 1) {
        return list;
    }

    // Define the pivot point, as well as left and right partitions
    let pivot = list[0];
    let leftList = [];
    let rightList = [];

    // Iterate over list and partition elements into left and right lists
    for (let i=1; i < list.length; i++) {

        if (list[i] < pivot) {
            leftList.push(list[i]);    
        } else {
            rightList.push(list[i]);
        }
    }
    
    // Recursive calls using the partitions as parameters and concatenating all the partitions into the final sorted array
    let sorted = sortedList(leftList).concat(pivot, sortedList(rightList));

    return sorted;
}


vowelsList = (list) => {

    // Function to filter a list of strings to only include strings that start with a vowel

    // Initialize an empty array to hold filtered results
    let filtered = [];

    // for loop with nested loop to iterate and test if string in words array starts with a vowel from vowels array
    for (i = 0; i < list.length; i++) {
        for (j = 0; j < vowels.length; j++) {
            if (list[i].startsWith(vowels[j])) {

                // Push element onto new array if string starts with a vowel
                filtered.push(list[i]);
            } 
        }
    }

    return filtered;
}


noVowelsList = (list) => {

    // Function to filter a list of strings to only include strings that do not start with a vowel

    // Initialize an empty array to hold filtered results
    let filtered = []; 

    // for loop with nested loop to test if string in words array starts with a vowel; use boolean flag to determine eligibility 
    for (let i = 0; i < list.length; i++) {
        let startsWithVowel = false;
        for (let j = 0; j < vowels.length; j++) {
            if (list[i].startsWith(vowels[j])) {
                startsWithVowel = true;

                // Exit the inner loop early if a vowel is found
                break; 
            } 
        }
        if (!startsWithVowel) {

            // Only add words that do not start with a vowel
            filtered.push(list[i]); 
        }
    }

    return filtered;
}


console.log(sortedList(words)); // should print ['all', 'cat', 'dog', 'down', 'extra', 'over', 'teach', 'up', 'world cup']

console.log(vowelsList(words)); // should print ['all', 'extra', 'over', 'up']

console.log(noVowelsList(words)); //should print ['cat' 'dog', 'down', 'teach', 'world cup']
