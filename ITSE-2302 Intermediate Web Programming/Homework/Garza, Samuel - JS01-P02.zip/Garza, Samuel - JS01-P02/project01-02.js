/*  JavaScript 7th Edition
    Chapter 1
    Hands-On Project 1-2
    Author: Samuel Garza
    Date: 02/07/2024
    Filename: project01-02.js
*/

// Define variables for service name and service speed.
var service1Name = "Basic", service1Speed = "0 Mbps";

var service2Name = "Express", service2Speed = "100Mbps";

var service3Name = "Extreme", service3Speed = "500 Mbps";

var service4Name = "Ultimate", service4Speed = "1 Gig";