from ArrayList import ArrayList

myStringList = ArrayList(["Alabama", "Alaska", "Arizona"])

lt = myStringList.listIterator()
lt.insert("Wyoming")
lt.first()
lt.next()
lt.replace("Texas")
lt.next()
lt.replace("Vermont")
print(myStringList)