"""
File: ArrayList.py
Author: Ken Lambert
"""

from Array import Array
from AbstractList import AbstractList
from ArrayListIterator import ArrayListIterator

class ArrayList(AbstractList):
    """ An array-based list implementation """

    DEFAULT_CAPACITY = 10

    def __init__(self, sourceCollection = None):
        """ Sets the initial state of self, which includes the contents of sourceCollection, if it's present. """
        self.items = Array(ArrayList.DEFAULT_CAPACITY)
        AbstractList.__init__(self, sourceCollection)

    # Accessor methods
    def __iter__(self):
        """Supports iteration over a view of self."""
        cursor = 0
        while cursor < len(self):
            yield self.items[cursor]
            cursor += 1

    def __getitem__(self, i):
        """Precondition: 0 <= i < len(self)
        Returns the item at position i.
        Raises: IndexError."""
        if i < 0 or i >= len(self):
            raise IndexError("List index out of range")
        return self.items[i]

    # Mutator methods
    def __setitem__(self, i, item):
        """Precondition: 0 <= i < len(self):
        Replaces the item at position i.
        Raises: IndexError."""
        if i < 0 or i >= len(self):
                raise IndexError("List index out of range")
        self.items[i] = item


    def insert(self, i, item):
        """Inserts the item at position i."""
        # Resize array here if necessary
        if i < 0: i = 0
        elif i > len(self): i = len(self)
        
        if i < len(self):
            for j in range(len(self), i, -1):
                self.items[j] = self.items[j - 1]
        
        self.items[i] = item
        self.size += 1
        self.incModCount()

    def add(self, item):
        """ Adds item to the last position in the list """
        # Check that the List is not full
        self.insert(self.size, item)

    def pop(self, index):
        """Removes the item at index."""
        self.replace(index, item = None)

    def remove(self, item):
        """ Removes the item provided if it exists in the list. """
        if item in self.items:
            i = self.index(item)
            while i <= self.size:
                self.replace(i, self.items[i + 1])
                i += 1
        else:
            print("The item is not in the list")
            raise

    def replace(self, index, item):
        self.items[index] = item

    def listIterator(self):
        """Returns a list iterator."""
        return ArrayListIterator(self)