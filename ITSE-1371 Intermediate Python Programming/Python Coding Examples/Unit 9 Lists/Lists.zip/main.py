lyst = ["Alabama", "Alaska", "Arizona"]

lyst.append("Arkansas")
print(lyst)
lyst.insert(4, "Iowa")
lyst.insert(5, "Puerto Rico")
print(lyst)
lyst.remove('Alaska')
print(lyst)
lyst.pop(4)
print(lyst)