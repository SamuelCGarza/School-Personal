lyst = ["Alabama", "Alaska", "Arizona"]

lyst.append("Wyoming")
print(lyst)
lyst.remove("Alabama")
print(lyst)
print(lyst.index("Arizona"))

if "New York" in lyst:
    print("New York is in the list")
else:
    print("New York is not in the list")