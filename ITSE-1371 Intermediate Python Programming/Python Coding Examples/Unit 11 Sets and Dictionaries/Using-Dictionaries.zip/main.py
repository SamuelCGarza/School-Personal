dict = {
    'profile' : 'Super Star Destroyer',
    'company' : 'Kuat Engineering',
    'owner' : 'Galactic Empire'
}

print(dict.keys())
print(dict.values())
print(dict.get('company'))
dict['crew'] = '280,000'

print(len(dict))

for k in dict:
    print(k)

dict.pop('owner')

for i in dict.items():
    print(i)

