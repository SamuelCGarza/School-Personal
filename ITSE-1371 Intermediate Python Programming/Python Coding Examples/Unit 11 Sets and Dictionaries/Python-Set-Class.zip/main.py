A = set([0, 1, 2])
B = set()
print(1 in A)
print(1 in B)
B.add(1)
B.add(1)
B.add(5)
print('B contains the following: ')
print(B) # Contains only one '1'
print('The difference between A and B is : ')
C = A.difference(B) # Elements that are in A but not in B
print(C)
print('The intersection between A and B is : ') 
C = A.intersection(B) # Common elements in both A and B
print(C)
B.remove(5)
print(B)
print(B.issubset(A))