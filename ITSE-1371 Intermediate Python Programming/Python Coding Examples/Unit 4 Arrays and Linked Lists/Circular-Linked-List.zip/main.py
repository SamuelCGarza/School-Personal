# The Node class which makes up the Linked List
class Node: 
    def __init__(self, data=None):
        self.data = data
        self.next = None


# The CircularLinkedList Class
class CircularLinkedList:
    def __init__(self):
        self.head = None

    def printList(self):
        head = self.head # Set the current node as the head
        while(True):
            print(head.data) # Read the node data
            head = head.next # Set the current node as the next node in the linked list
            # Create a condition to break out of the loop
            if head == self.head:
                break


# Create the list and the list's nodes
list = CircularLinkedList()
list.head = Node(1)
n2 = Node(2)
n3 = Node(3)

# Link the nodes
list.head.next = n2
n2.next = n3
n3.next = list.head # The last node points back to the "head"

# Print the CircularLinkedList
list.printList()
