# The Node class which makes up the Linked List
class Node: 
    def __init__(self, data=None):
        self.data = data
        self.next = None


# The SinglyLinkedList Class
class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def searchList(self, target):
        head = self.head # Set the current node as the head
        while head is not None: 
            if head.data == target: # Read the node data
                return True
            head = head.next # Set the current node as the next node in the linked list
    

# Create the list and the list's nodes
list = SinglyLinkedList()
list.head = Node(1)
n2 = Node(2)
n3 = Node(3)
# Link the nodes
list.head.next = n2
n2.next = n3

# Search the list
target = 2
if list.searchList(target):
    print(f'{target} was found in the list')
else:
    print(f'{target} was not found in the list')
