# The Node class which makes up the Linked List
class Node: 
    def __init__(self, data=None):
        self.data = data
        self.next = None


# The SinglyLinkedList Class
class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def printList(self):    
        head = self.head
        while head is not None:
            print(head.data)
            head = head.next

    def insertMid(self, prevNode, newNode):
        if prevNode is not None:
            newNode.next = prevNode.next # The new node points to the next node in the list
            prevNode.next = newNode # The preceeding node points to the new node
        else:
            print('The provided node must not be of type None')

    def insertHead(self, newNode):
        newNode.next = self.head
        self.head = newNode # The head node is now the newNode

    def insertTail(self, newNode):
        if self.head is None: # Check if the list is empty
            self.head = newNode # Insert the newNode if the list is empty
            return
        
        current = self.head
        while current.next: # Traverse the linked list until the last node
            current = current.next

        current.next = newNode # Set the new node as the tail node

# Create the list and the list's nodes
list = SinglyLinkedList()
list.head = Node(1)
n2 = Node(2)
n3 = Node(3)
list.head.next = n2
n2.next = n3
# Create new nodes to insert into the list
n4 = Node(4)
n5 = Node(5)
n6 = Node(6)
list.insertMid(n2, n4)
list.insertHead(n5)
list.insertTail(n6)
list.printList()

