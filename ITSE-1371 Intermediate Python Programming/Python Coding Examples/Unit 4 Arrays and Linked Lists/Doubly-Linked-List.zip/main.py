# The Node class which makes up the Linked List
class Node: 
    def __init__(self, data=None):
        self.data = data
        self.prev = None
        self.next = None


# The DoublyLinkedList Class
class DoublyLinkedList:
    def __init__(self):
        self.head = None

    def printList(self):
        head = self.head
        while head is not None:
            print(head.data)
            head = head.next


# Create the list and the list's nodes
list = DoublyLinkedList()
list.head = Node(1)
n2 = Node(2)
n3 = Node(3)

# Link the nodes
list.head.next = n2
n2.prev = list.head
n2.next = n3
n3.prev = n2

# Print the DoublyLinkedList
list.printList()


