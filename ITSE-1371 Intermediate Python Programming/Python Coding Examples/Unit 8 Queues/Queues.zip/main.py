import Queue

queue = Queue.Queue()
for i in range(0, 10):
    queue.add(i)
print(queue)
print(queue.peek())
print(queue.pop())
print(queue.pop())
print(queue.peek())
print(queue)
