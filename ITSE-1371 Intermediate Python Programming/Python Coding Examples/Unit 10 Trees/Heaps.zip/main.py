from arrayheap import ArrayHeap

def main():
    min_heap = ArrayHeap()
    print("Adding 100 75 50 45 40 20 10")
    min_heap.add(100)
    min_heap.add(75)
    min_heap.add(50)
    min_heap.add(45)
    min_heap.add(40)
    min_heap.add(20)
    min_heap.add(10)
    print("The starting heap...")
    print(min_heap)

    # Inserting a new smallest node into the min-heap
    min_heap.add(5)
    print("The heap after an insertion...")
    print(min_heap)
    
    # Removing the smallest node in the min-heap
    min_heap.pop()
    print("The heap after a pop...")
    print(min_heap)

if __name__ == "__main__":
    main()


