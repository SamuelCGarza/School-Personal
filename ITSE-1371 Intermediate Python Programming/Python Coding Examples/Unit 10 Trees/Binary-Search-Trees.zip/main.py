from linkedbst import LinkedBST

def main():
    tree = LinkedBST()
    print('Adding 4 2 1 3 5 7 8 9')
    tree.add(4)
    tree.add(2)
    tree.add(1)
    tree.add(3)
    tree.add(7)
    tree.add(5)
    tree.add(8)
    tree.add(9)

    print(tree)
    if tree.find(8):
        print(True)

if __name__ == '__main__':
    main()