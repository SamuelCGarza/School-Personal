from binarytree import BinaryTree

def main():
    tree = BinaryTree()
    print("Adding D B A C F E G\n")
    tree.add("D")
    tree.add("B")
    tree.add("A")
    tree.add("C")
    tree.add("F")
    tree.add("E")
    tree.add("G")

    print(tree)

if __name__ == "__main__":
    main()
