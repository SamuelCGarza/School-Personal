from binarytree import BinaryTree

def main():
    tree = BinaryTree()
    print("Adding D B A C F E G\n")
    tree.add("D")
    tree.add("B")
    tree.add("A")
    tree.add("C")
    tree.add("F")
    tree.add("E")
    tree.add("G")

    print(tree)
    print("\n\ninorder traversal: ", end="")
    for item in tree.inorder(): print(item, end = " ")
    
    print("\n\npreorder traversal: ", end="")
    for item in tree.preorder(): print(item, end = " ")
    
    print("\n\npostorder traversal: ", end="")
    for item in tree.postorder(): print(item, end = " ")
    
    print("\n\nlevelorder traversal: ", end="")
    for item in tree.levelorder(): print(item, end = " ")

if __name__ == "__main__":
    main()
