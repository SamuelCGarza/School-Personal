lyst = [3, 1, 8, 5, 9, 7, 2, 4, 6]
print("Unsorted List:")
print(lyst)


def insertionSort(lyst):
    i = 1
    while i < len(lyst):
        itemToInsert = lyst[i]
        j = i - 1
        while j >= 0:
            if itemToInsert < lyst[j]:
                lyst[j + 1] = lyst[j]
                j -= 1
            else:
                break
        lyst[j + 1] = itemToInsert
        i += 1
    
print("\nSorted List:")
insertionSort(lyst)
print(lyst)
