lyst = [3, 1, 8, 5, 9, 7, 2, 4, 6]
print("Unsorted List:")
print(lyst)

def quicksort(lyst, low, high):
    if low < high:
        par_index = partition(lyst, low, high)
        quicksort(lyst, low, par_index - 1)
        quicksort(lyst, par_index + 1, high)

def partition(lyst, low, high):
    i = low - 1
    # This pivot is using the last element in the sublist
    pivot = lyst[high]
    for j in range(low, high):
        if lyst[j] <= pivot:
            i += 1
            lyst[i], lyst[j] = lyst[j], lyst[i]
    lyst[i + 1], lyst[high] = lyst[high], lyst[i + 1]
    return i + 1

quicksort(lyst, 0, len(lyst) - 1)
print("\nSorted List:")
print(lyst)