lyst = [5, 3, 2, 4, 1]
print('Unsorted List:')
print(lyst)

# Create the sorted sublist
for i in range(len(lyst)):
    minVal = i

    # Iterate through the unsorted sublist, beginning at i + 1
    for j in range(i + 1, len(lyst)):
        if lyst[minVal] > lyst[j]:
            minVal = j
    
    # Swap the smallest element in the unsorted sublist with the current index (i) 
    lyst[i], lyst[minVal] = lyst[minVal], lyst[i]

print('\nSelection Sorted List:')
print(lyst)
