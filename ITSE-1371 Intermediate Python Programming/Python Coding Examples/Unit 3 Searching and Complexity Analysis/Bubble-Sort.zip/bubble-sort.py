arr = [5, 1, 3, 2, 4]
print("Unsorted Array:")
print(arr)

# Traverse the list once for each element in the list
for i in range(len(arr)):
    # Step through the list one index at a time
    for j in range(0, len(arr) - 1):
       # Compare the value of the current index with the value in the following index
       if arr[j] > arr[j + 1]:
           # Swap the values if needed
           arr[j], arr[j + 1] = arr[j + 1], arr[j]

print("\nBubble Sorted Array:")
print(arr)
