""" Graph implementation using an adjacency list """
key_lookup = {0 : 'A', 2 : 'B', 1 : 'C', 3 : 'D'}
"""
    A
  / | \ 
 D --- C
  \ | /
    B
"""
graph = {'A' : [[1,2], [3, 2], [2,4]],
        'C' : [[0,2], [2,2], [3,4]], 
        'B' : [[0, 4], [1, 2], [3,2]],
        'D' : [[0,2], [1,4], [2,2]]}

def print_graph(g):
    for vertex in g.keys():
        for edge in g[vertex]:
            print(f'{vertex} --({edge[1]})--> {key_lookup[edge[0]]}')

# Recursive Depth First Traversal
def dft(vertex, visited):
    ''' Recursively calls the dft() function on vertices of the graph until all vertices connected by an edge to the source vertex
    have been visited. '''
    # Each vertex provided to the dft() function has not previously been visited. Mark the current vertex as visited. 
    visited[vertex] = True
    print(f'{key_lookup[vertex]}')
    # Iterate through the current vertex's connections
    for i in graph[key_lookup[vertex]]: 
        # Check each connection for the destination vertex, if that vertex has not been visited, call dft() on that vertex
        if visited[i[0]] == False:
            dft(i[0], visited)

print('The vertices and edges of the graph: \n')
print_graph(graph)

print('\nDepth First Traversal: ')
vertex_has_been_visited = [False] * len(graph.keys())
dft(0, vertex_has_been_visited)
