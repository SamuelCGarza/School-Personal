""" Graph implementation using an adjacency list """
key_lookup = {0 : 'A', 2 : 'B', 1 : 'C', 3 : 'D'}
"""
    A
  / | \
 D --- C
  \ | /
    B
"""
graph = {'A' : [[1,2], [3, 2], [2,4]],
        'C' : [[0,2], [2,2], [3,4]], 
        'B' : [[0, 4], [1, 2], [3,2]],
        'D' : [[0,2], [1,4], [2,2]]}

def print_graph(g):
    for vertex in g.keys():
        for edge in g[vertex]:
            print(f'{vertex} --({edge[1]})--> {key_lookup[edge[0]]}')

def bft(vertex):
    ''' The vertex is the source or starting vertex, the vertex to start the traversal '''
    # No vertices have been visited, mark each as False
    vertex_has_been_visited = [False] * len(graph.keys())
    queue = []
    queue.append(vertex)
    # Mark the starting vertex as visited
    vertex_has_been_visited[vertex] = True
    while queue:
        # Pop the next vertex to check
        s = queue.pop(0)
        print(f'{key_lookup[s]}')
        # For each edge on the current vertex
        for i in graph[key_lookup[s]]:
            # Check if the vertex has been visited
            if vertex_has_been_visited[i[0]] == False:
                # If it has not, add it to the queue
                queue.append(i[0])
                # Mark the vertex as visited so it is not added to the queue again
                vertex_has_been_visited[i[0]] = True
        

print('The vertices and edges of the graph: \n')
print_graph(graph)

print('\nBreadth First Traversal: ')
bft(0)