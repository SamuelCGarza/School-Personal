import Stack

stack = Stack.Stack()
for i in range(0, 10):
    stack.push(i)
print(stack)
print(stack.peek())
print(stack.pop())
print(stack.pop())
print(stack.peek())
print(stack)
