import Array
class Stack(object):

    DEFAULT_CAPACITY = 10

    def __init__(self, sourceCollection = None):
        """ Sets the initial state of self, which includes the contents of sourceCollection, if it's present """
        self.items = Array.Array(Stack.DEFAULT_CAPACITY)
        self.size = 0
        

    def isEmpty(self):
        """ Returns True if x is empty or False otherwise """
        if len(self) == 0:
            return True
        else:
            return False

    def __len__(self):
        """ Same as len(x). Returns the number of items in self """
        return len(self.items) - 1
        

    def __str__(self):
        """ Same as str(s). Returns the string representation of self """
        return str(self.items)

    def __iter__(self):
        """ Same as iter(s), or for item in self: Visits each item in self, from bottom to top """
        cursor = 0
        while cursor < len(self):
            yield self.items[cursor]
            cursor += 1

    def clear(self):
        """ Makes self become empty """
        self.size = 0
        self.items = Array.Array(Stack.DEFAULT_CAPACITY)

    def peek(self):
        """ Returns the item at the top of self. 
        Preconditions: self must not be empty, raises a KeyError if the stack is empty """
        return self.items[self.size - 1]

    def push(self, item):
        """ Adds item to the top of self """
        self.items[self.size] = item
        self.size += 1

    def pop(self):
        """ Removes and returns the item at the top of self.
        Preconditions: self must not be empty, raises a KeyError if the stack is empty """
        oldItem = self.items[self.size - 1]
        self.items[self.size - 1] = None
        self.size -= 1
        return oldItem
