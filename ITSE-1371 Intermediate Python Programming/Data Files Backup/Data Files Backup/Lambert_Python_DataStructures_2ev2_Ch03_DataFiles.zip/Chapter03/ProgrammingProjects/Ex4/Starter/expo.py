"""
File: expo.py
Project 3.4

Defines a function to raise a number to a given power.
Computational complexity: 
"""

def expo(base, exponent):
    """Raises base to exponent."""
   
def main():
    """Tests with powers of 2."""
    for exponent in range (5):
        print(exponent, expo(2, exponent))

if __name__ == "__main__":
    main()    
