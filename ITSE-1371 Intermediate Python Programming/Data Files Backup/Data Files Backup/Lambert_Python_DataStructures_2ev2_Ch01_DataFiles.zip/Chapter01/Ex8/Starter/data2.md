Kevin 67 100.85
Will 50 90.90
Smith 5 100.80