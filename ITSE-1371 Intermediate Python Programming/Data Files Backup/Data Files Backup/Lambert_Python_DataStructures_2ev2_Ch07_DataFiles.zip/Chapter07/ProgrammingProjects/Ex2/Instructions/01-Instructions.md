Write a program that uses a `stack` to test input strings to determine whether they
are __palindromes__. A palindrome is a sequence of characters that reads the same as
the sequence in reverse; for example, _noon_.

Changes should be made in the _palindrome.py_ file.
