"""
Determine the running time of the == operation for the two bag implementations.

"""
