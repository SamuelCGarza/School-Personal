"""
Determine the running time of the + operator for the two bag implementations.

"""
