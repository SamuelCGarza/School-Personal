"""
Determine the running time of the add method of ArraySortedBag.

"""
