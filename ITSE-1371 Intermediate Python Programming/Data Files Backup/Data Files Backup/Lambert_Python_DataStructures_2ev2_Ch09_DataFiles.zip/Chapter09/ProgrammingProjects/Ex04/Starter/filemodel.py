"""
File: filemodel.py
Project 9.4

Data model for a file viewer.  Supports navigation
through the lines of a file.
"""

from linkedlist import LinkedList

class FileModel(object):

    def __init__(self, filename):


    def first(self):


    def last(self):


    def next(self):


    def previous(self):


